//Script_RespawnOnDeath
//Made by Cruxeis, BL_ID 35041

package respawnOnDeathPackage {
	
function GameConnection::onDeath(%this, %killerPlayer, %killer, %damageType, %damageLoc)
{
	Parent::onDeath(%this, %killerPlayer, %killer, %damageType, %damageLoc);
	%this.spawnPlayer();
}

function Slayer_MinigameSO::addMember(%this, %member)
{
	Parent::addMember(%this, %member);
	if(!%member.hasSpawnedOnce)
	{
		%member.spawnPlayer();
		%member.player.kill();
	}
}

};

activatePackage(respawnOnDeathPackage);