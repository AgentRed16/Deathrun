//-----------------------------------------
//MADE BY : RAMMBOY
//BLID    : 19748
//-----------------------------------------

//-----------------------------------------
//DÉCLARATION PARTICULES

datablock particleData(TrailRainbowLaser_Mounted_Particule)
{
    colors[0]     = "1 0 0 1";
	colors[1]     = "0 1 0 1";
	colors[2]     = "0 0 1 1";
	colors[3]     = "1 0 1 0";

	sizes[0]      = 0.8;
	sizes[1]      = 0.4;
	sizes[2]      = 0.2;
	sizes[3]      = 0;
	
	times[0] = 0;
	times[1] = 0.5;
	times[2] = 1;
	times[3] = 1.5;
		
	gravityCoefficient = 0;
	dragCoefficient      = 0.0;
	lifetimeMS         = 1600;
	lifetimeVarianceMS = 100;
	spinRandomMax      = 0;
	spinRandomMin      = 0;
	textureName        = "base/data/particles/dot.png";
	useInvAlpha   = false;
};

datablock particleEmitterData(TrailRainbowLaser_Mounted_Emitter)
{
	ejectionOffset   = 0.00;
	ejectionPeriodMS = 8;
	ejectionVelocity = 0.0;
	particles        = TrailRainbowLaser_Mounted_Particule;
	periodVarianceMS = 1;
	thetaMax         = 180;
	velocityVariance = 0;
	overrideAdvance = false;
	
	colors[0]     = "1 0 0 1";
	colors[1]     = "0 1 0 1";
	colors[2]     = "0 0 1 1";
	colors[3]     = "1 0 1 0";

	sizes[0]      = 0.2;
	sizes[1]      = 0.13;
	sizes[2]      = 0.07;
	sizes[3]      = 0;
	
	times[0] = 0;
	times[1] = 0.5;
	times[2] = 1;
	times[3] = 1.5;
};

//-----------------------------------------
//DÉCLARATION OBJECT

datablock ItemData(TrailRainbowLaser)
{
  uiName = "Trail Rainbow Laser";
  image = TrailRainbowLaser_Image;
  category = "Tools";
  className = "Weapon";
  shapeFile = "base/data/shapes/empty.dts";
  mass = 0.5;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};

datablock ShapeBaseImageData(TrailRainbowLaser_Image)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = true;
  mountPoint = 0;
  className = "WeaponImage";
  item = TrailRainbowLaser_Item;
  melee = false;
  doReaction = false;
  armReady = false;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;

  stateName[2] = "Fire";
  stateTransitionOnTriggerUp[2] = "Ready";
  stateTimeoutValue[2] = "0.2";
  stateFire[2] = true;
  stateAllowImageChange[2] = true;
  stateScript[2] = "onFire";
 
};

datablock ShapeBaseImageData(TrailRainbowLaserImage)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = true;
  mountPoint = 2;
  offset = "0 0 -0.15";
  eyeOffset = "0 0 -1.5";
  eyeRotation = eulerToMatrix("-90 0 0");
  scale = "1 1 1";
  correctMuzzleVector = true;
  doColorShift = false;
  colorShiftColor = "1 1 1 1";
  
  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Idle";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Idle";
  stateAllowImageChange[1] = true;
  stateEmitter[1] = TrailRainbowLaser_Mounted_Emitter;
  stateEmitterNode[1]				= "muzzleNode";
  stateEmitterTime[1]				= 10000;

};

//-----------------------------------------
//DÉCLARATION FONCTION

function TrailRainbowLaser_Image::onFire(%this,%obj,%slot)
{
  %client = %obj.client;
  %player = %obj;
  if(isObject(%player))
  {
    if(%player.getMountedImage(2) $= nametoID(TrailRainbowLaser_Mounted_Image)) %player.unmountImage(2);
    else
    {
      %player.unmountImage(2);
      %player.mountImage(TrailRainbowLaser_Mounted_Image,2);
    }
  }
}

//-----------------------------------------

