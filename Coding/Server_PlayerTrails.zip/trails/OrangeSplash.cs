//Player Trails - Orange Splash
//Made by Cruxeis, BL_ID 35041

datablock particleData(TrailOrangeSplashParticle)
{
	colors[1]		   = "1 0.35 0 1";
    colors[2]		   = "1 0.35 0 1";
	colors[3]		   = "0 0 0 0";
	sizes[1]    	   = 0.5;
	sizes[2]    	   = 0.25;
	sizes[3]    	   = 0;
	times[1] 		   = 0;
	times[2] 		   = 0.5;
	times[3] 		   = 1;
	gravityCoefficient = 0;
	lifetimeMS         = 2000;
	lifetimeVarianceMS = 100;
	spinRandomMax      = 0;
	spinRandomMin      = 0;
	textureName        = "base/data/particles/dot.png";
	useInvAlpha		   = false;
};

datablock particleEmitterData(TrailOrangeSplashEmitter)
{
	ejectionOffset   = 0.00;
	ejectionPeriodMS = 10;
	ejectionVelocity = 1;
	orientParticles  = false;
	particles        = TrailOrangeSplashParticle;
	periodVarianceMS = 0;
	thetaMax		 = 90;
	thetaMin		 = 0;
	velocityVariance = 0;
};

datablock ShapeBaseImageData(TrailOrangeSplashImage)
{
  shapeFile 		  = "base/data/shapes/empty.dts";
  emap 				  = true;
  mountPoint 		  = 2;
  offset			  = "0 0 -0.15";
  eyeOffset			  = "0 0 -1.5";
  eyeRotation 		  = eulerToMatrix("-90 0 0");
  scale 			  = "1 1 1";
  correctMuzzleVector = true;
  doColorShift 		  = false;
  colorShiftColor	  = "1 1 1 1";
  
  stateName[0] 			   = "Idle";
  stateAllowImageChange[0] = true;
  stateEmitter[0] 		   = TrailOrangeSplashEmitter;
  stateEmitterNode[0]	   = "muzzleNode";
  stateEmitterTime[0]	   = 10000;
};

