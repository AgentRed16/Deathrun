//Player Trails - Dark Splash
//Made by Cruxeis, BL_ID 35041

datablock particleData(TrailDarkSplashParticle)
{
	colors[1]		   = "0.5 0.5 0.5 1";
    colors[2]		   = "0.25 0.25 0.25 1";
	colors[3]		   = "0 0 0 0";
	sizes[1]    	   = 0.5;
	sizes[2]    	   = 0.25;
	sizes[3]    	   = 0;
	times[1] 		   = 0;
	times[2] 		   = 0.5;
	times[3] 		   = 1;
	gravityCoefficient = 0;
	lifetimeMS         = 2000;
	lifetimeVarianceMS = 100;
	spinRandomMax      = 0;
	spinRandomMin      = 0;
	textureName        = "base/data/particles/dot.png";
	useInvAlpha		   = true;
};

datablock particleEmitterData(TrailDarkSplashEmitter)
{
	ejectionOffset   = 0.00;
	ejectionPeriodMS = 30;
	ejectionVelocity = 1;
	orientParticles  = false;
	particles        = TrailDarkSplashParticle;
	periodVarianceMS = 0;
	thetaMax		 = 90;
	thetaMin		 = 0;
	velocityVariance = 0;
};

datablock ShapeBaseImageData(TrailDarkSplashImage)
{
  shapeFile 		  = "base/data/shapes/empty.dts";
  emap 				  = true;
  mountPoint 		  = 2;
  offset			  = "0 0 -0.15";
  eyeOffset			  = "0 0 -1.5";
  eyeRotation 		  = eulerToMatrix("-90 0 0");
  scale 			  = "1 1 1";
  correctMuzzleVector = true;
  doColorShift 		  = false;
  colorShiftColor	  = "1 1 1 1";
  
  stateName[0] 			   = "Idle";
  stateAllowImageChange[0] = true;
  stateEmitter[0] 		   = TrailDarkSplashEmitter;
  stateEmitterNode[0]	   = "muzzleNode";
  stateEmitterTime[0]	   = 10000;
};

