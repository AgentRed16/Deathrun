//Player Trails - Body Shield
//Made by Cruxeis, BL_ID 35041

datablock particleData(TrailBodyShieldParticle)
{
	colors[1]		   = "1 0.35 0 1";
    colors[2]		   = "1 0.35 0 0.5";
	colors[3]		   = "0 0 0 0";
	sizes[1]    	   = 4.5;
	sizes[2]    	   = 4.6;
	sizes[3]    	   = 4.7;
	times[1] 		   = 0;
	times[2] 		   = 0.05;
	times[3] 		   = 1;
	gravityCoefficient = 0;
	lifetimeMS         = 500;
	lifetimeVarianceMS = 0;
	spinRandomMax      = 0;
	spinRandomMin      = 0;
	textureName        = "base/data/particles/thinRing.png";
	useInvAlpha		   = false;
};

datablock particleEmitterData(TrailBodyShieldEmitter)
{
	ejectionOffset   = 0.00;
	ejectionPeriodMS = 75;
	ejectionVelocity = 0.00;
	orientParticles  = false;
	particles        = TrailBodyShieldParticle;
	periodVarianceMS = 10;
	thetaMax		 = 90;
	thetaMin		 = 0;
	velocityVariance = 0;
};

datablock ShapeBaseImageData(TrailBodyShieldImage) 
{
  shapeFile 		  = "base/data/shapes/empty.dts";
  emap 				  = true;
  mountPoint 		  = 2;
  offset			  = "0 0 -0.15";
  eyeOffset			  = "0 0 -1.5";
  eyeRotation 		  = eulerToMatrix("-90 0 0");
  scale 			  = "1 1 1";
  correctMuzzleVector = true;
  doColorShift 		  = false;
  colorShiftColor	  = "1 1 1 1";
  
  stateName[0] 			   = "Idle";
  stateAllowImageChange[0] = true;
  stateEmitter[0] 		   = TrailBodyShieldEmitter;
  stateEmitterNode[0]	   = "muzzleNode";
  stateEmitterTime[0]	   = 10000;
};

