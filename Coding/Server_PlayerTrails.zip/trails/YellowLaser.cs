//Player Trails - Yellow Laser
//Made by Cruxeis, BL_ID 35041

datablock particleData(TrailYellowLaserParticle)
{
	colors[1]		   = "1 1 0 1";
    colors[2]		   = "0.5 0.5 0 0.5";
	colors[3]		   = "0 0 0 0";
	sizes[1]    	   = 0.4;
	sizes[2]    	   = 0.8;
	sizes[3]    	   = 0;
	times[1] 		   = 0;
	times[2] 		   = 0.05;
	times[3] 		   = 1;
	gravityCoefficient = 0;
	lifetimeMS         = 4000;
	lifetimeVarianceMS = 100;
	spinRandomMax      = 0;
	spinRandomMin      = 0;
	textureName        = "base/data/particles/dot.png";
	useInvAlpha		   = false;
};

datablock particleEmitterData(TrailYellowLaserEmitter)
{
	ejectionOffset   = 0.00;
	ejectionPeriodMS = 1;
	ejectionVelocity = 0.00;
	orientParticles  = false;
	particles        = TrailYellowLaserParticle;
	periodVarianceMS = 0;
	thetaMax		 = 180;
	thetaMin		 = 0;
	uiName           = "Yellow Laser Emitter";
	velocityVariance = 0;
};

datablock ShapeBaseImageData(TrailYellowLaserImage) 
{
  shapeFile 		  = "base/data/shapes/empty.dts";
  emap 				  = true;
  mountPoint 		  = 2;
  offset			  = "0 0 -0.15";
  eyeOffset			  = "0 0 -1.5";
  eyeRotation 		  = eulerToMatrix("-90 0 0");
  scale 			  = "1 1 1";
  correctMuzzleVector = true;
  doColorShift 		  = false;
  colorShiftColor	  = "1 1 1 1";
  
  stateName[0] 			   = "Idle";
  stateAllowImageChange[0] = true;
  stateEmitter[0] 		   = TrailYellowLaserEmitter;
  stateEmitterNode[0]	   = "muzzleNode";
  stateEmitterTime[0]	   = 10000;
};

