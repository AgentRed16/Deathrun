//Player Trails - Head Shield
//Made by Cruxeis, BL_ID 35041

datablock particleData(TrailHeadShieldParticle)
{
	colors[1]		   = "0 0.5 1 1";
    colors[2]		   = "0 0.5 1 0.5";
	colors[3]		   = "0 0 0 0";
	sizes[1]    	   = 2;
	sizes[2]    	   = 2.2;
	sizes[3]    	   = 0;
	times[1] 		   = 0;
	times[2] 		   = 0.05;
	times[3] 		   = 1;
	gravityCoefficient = 0;
	lifetimeMS         = 500;
	lifetimeVarianceMS = 0;
	spinRandomMax      = 0;
	spinRandomMin      = 0;
	textureName        = "base/data/particles/ring.png";
	useInvAlpha		   = false;
};

datablock particleEmitterData(TrailHeadShieldEmitter)
{
	ejectionOffset   = 0.00;
	ejectionPeriodMS = 50;
	ejectionVelocity = 0.00;
	orientParticles  = false;
	particles        = TrailHeadShieldParticle;
	periodVarianceMS = 10;
	thetaMax		 = 90;
	thetaMin		 = 0;
	velocityVariance = 0;
};

datablock ShapeBaseImageData(TrailHeadShieldImage) 
{
  shapeFile 		  = "base/data/shapes/empty.dts";
  emap 				  = true;
  mountPoint 		  = $headSlot;
  offset			  = "0 0 0";
  eyeOffset			  = "0 0 0";
  eyeRotation 		  = eulerToMatrix("-90 0 0");
  scale 			  = "1 1 1";
  correctMuzzleVector = true;
  doColorShift 		  = false;
  colorShiftColor	  = "1 1 1 1";
  
  stateName[0] 			   = "Idle";
  stateAllowImageChange[0] = true;
  stateEmitter[0] 		   = TrailHeadShieldEmitter;
  stateEmitterNode[0]	   = "muzzleNode";
  stateEmitterTime[0]	   = 10000;
};

