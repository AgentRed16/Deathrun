//Emitter trails that follow your player!
//Made by Cruxeis, BL_ID 35041

function cruxTrails_init()
{
	$cruxTrailList = "BlueLaser BlueSplash BodyShield ColorfulSplash DarkSplash GreenLaser GreenSplash HeadShield OrangeSplash PurpleSplash RainbowLaser RedLaser RedSplash TurquoiseSplash WhiteSplash YellowLaser YellowSplash";
	%count = getWordCount($cruxTrailList);
	for(%i = 0; %i < %count; %i++)
	{
		%trail = getWord($cruxTrailList, %i);
		exec("./trails/" @ %trail @ ".cs");
	}
}

cruxTrails_init();

function serverCmdtrail(%client, %opt)
{
	if(%opt $= "" || %opt $= " ")
	{
		messageClient(%client, '', "\c4/trail \c5name \c6gives you a trail!");
		messageClient(%client, '', "\c4/listTrails \c6will list all of the available trails.");
		return;
	}	
	if(!isObject(%player = %client.player))
		return messageClient(%client, '', "\c6You must have a player!");
	if(strlwr(%opt) $= "none")
	{
		%player.unMountImage(2);
		%client.trail = "";
	}
	if(stripos($cruxTrailList, %opt) == -1)
		return messageClient(%client, '', "\c6That is not a valid trail. Do \c4/trail \c6for help.");
	if((%opt $= "ColorfulSplash" || %opt $= "RainbowLaser") && !%client.isAdmin)
		return messageClient(%client, '', "\c6You are not admin and can't use that trail!");
	%player.unMountImage(2);
	%image = "Trail" @ %opt @ "Image";
	%player.mountImage(%image, 2);
	messageClient(%client, '', "\c6Trail set to\c4" SPC %opt @ "\c6.");
	%client.trail = %opt;
}

function serverCmdlistTrails(%client)
{
	messageClient(%client, '', "\c6Here is a list of \c4trails\c6:");
	%count = getWordCount($cruxTrailList);
	for(%i = 0; %i < %count; %i++)
		messageClient(%client, '', "\c3" @ getWord($cruxTrailList, %i));
}

package playerTrailsPackage {
	
function GameConnection::spawnPlayer(%this)
{
	Parent::spawnPlayer(%this);
	if(%this.trail !$= "")
		serverCmdTrail(%this, %this.trail);
}

};

activatePackage(playerTrailsPackage);


	
	


	
	
	
	
	
	
	
	
	
	
	
	