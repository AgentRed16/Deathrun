function serverCmdSpawn(%client, %member)
{
    if(%client.slyrTeam.name $= "Runners" || %client.slyrTeam.name $= "Spectators")
		%client.removeFromMini();
}

function serverCmdSpec(%client)
{
	if(%client.minigame == getMinigameByTitle("Lobby"))
	{
		%client.removeFromMini();
		%client.addToMini("Deathrun");
	}
	else if(%client.slyrTeam.name $= "Spectators")
		%client.player.kill();
	else
		%client.joinTeam("Spectators");

}

package specSpawnPackage {

function serverCmdCancelBrick(%client)
{
	Parent::serverCmdCancelBrick(%client);
	serverCmdSpec(%client);
}

};

activatePackage(specSpawnPackage);