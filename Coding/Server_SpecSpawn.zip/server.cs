function serverCmdSpawn(%client, %member)
{
    if(%client.slyrTeam.name $= "Runners" || %client.slyrTeam.name $= "Spectators")
		%client.removeFromMini();
}

function serverCmdSpec(%client)
{
	if(%client.minigame == getMinigameByTitle("Lobby"))
	{
		%client.removeFromMini();
		%client.addToMini("Deathrun");
	}
	else if(!isObject(%client.player))
	{
		%client.spawnplayer();
		%client.joinTeam("Spectators");
	}
	else if(%client.slyrTeam.name $= "Spectators")
	{
		%client.player.kill();
	}
	else if(%client.slyrTeam.name $= "Runners")
	{
		%client.joinTeam("Spectators");
	}
	else if(%client.slyrTeam.name $= "Death")
	{
		messageClient(%client, '', "\c3 You\c6 are\c7 Death\c6. You cannot spectate.");
	}
}

package specSpawnPackage {

function serverCmdCancelBrick(%client)
{
	Parent::serverCmdCancelBrick(%client);
	serverCmdSpec(%client);
}

};

activatePackage(specSpawnPackage);