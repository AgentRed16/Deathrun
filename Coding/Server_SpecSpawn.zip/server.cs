function serverCmdSpawn(%client, %member)
{
    if(%client.slyrTeam.name $= "Runners" || %client.slyrTeam.name $= "Spectators")
    {
		%client.spawnplayer();
		%client.instantRespawn();
    }
}

function serverCmdSpec(%client)
{
        %client.player.kill();
}
