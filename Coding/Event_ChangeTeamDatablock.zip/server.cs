//Event_ChangeTeamDatablock
//Made by Cruxeis, BL_ID 35041

function Slayer_MinigameSO::changeTeamDatablock(%this, %team, %datablock)
{
	%team = %this.getTeam(%team);
	%count = %team.numMembers;
	for(%i = 0; %i < %count; %i++)
		%team.member[%i].player.changeDatablock(%datablock);
}

registerOutputEvent("Minigame", "changeTeamDatablock", "string 100 100" TAB "datablock PlayerData", false);