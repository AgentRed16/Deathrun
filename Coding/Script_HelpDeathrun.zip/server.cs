//////////////////
//Help Command Deathrun//////
//////////////////
//Author: Agent Red//
//////////////////

function servercmdHelp(%client,%topic,%Admin)
{
	if(%topic $= "")
	{
		messageClient(%client, '', "\c6Please Choose a Topic. (Ex: /help AdminRules)");
		messageClient(%client, '', "\c6-->\c0rules");
		messageClient(%client, '', "\c6-->\c1AdminRules");
		messageClient(%client, '', "\c6-->\c4moderator");
		messageClient(%client, '', "\c6-->\c3About");
		messageClient(%client, '', "\c6-->\c5Commands");
                messageClient(%client, '', "\c6-->\c2Admin");
		messageClient(%client, '', "\c6-->\c4KnownBugs");
		return;
	}

	if(%topic $= "rules")
	{
		messageClient(%client, '', "\c4Rules:");
                messageClient(%client, '', "\c61.  Do not cause needless arguments");
                messageClient(%client, '', "\c62.  Do not Ask/say you \"Need\" admin- We just wont just give admin, so please stop trying.");
                messageClient(%client, '', "\c63.  Do not spam (chat,musicbricks,emitters,lights, etc)");
                messageClient(%client, '', "\c64.  Play nicely");
		messageClient(%client, '', "\c65.  Do not cheat");
		messageClient(%client, '', "\c66.  Obey what the staff members say");
		messageClient(%client, '', "\c67.  Dont stall the game");
		return;
	}

	if(%topic $= "AdminRules")
	{
		messageClient(%client, '', "\c1AdminRules:");
		messageClient(%client, '', "\c61. Do not play around with your admin abilities while in a minigame in the server");
		messageClient(%client, '', "\c62. Do not change the environmental settings \"Server settings\" ");
                messageClient(%client, '', "\c63. Do not abuse your powers");
                messageClient(%client, '', "\c64. Never Un-Ban Anyone from the ban list, they were banned that long for a reason");
		messageClient(%client, '', "\c65. Do not Troll around -Includes eval");
		return;
	}

	
	if(%topic $= "moderator")
	{
		messageClient(%client, '', "\c4 If you are already Moderator, do /Mhelp");
		return;
	}
	
	if(%topic $= "About")
	{
		messageClient(%client, '', "\c3About \c6this server:");
		messageClient(%client, '', "\c61. Deathrun is a game�where players, called \c3Runners\c6 try to avoid the traps set�off by a�single�person, Aka \c8Death\c6. It is based off of skill and luck.�At the end, the Runners�challenge�the Death�to die");
		messageClient(%client, '', "\c62. This server was created by Agent Red, Rocket, K1ng S4vage, Chillah, Cruxeis, DatGuyT_T, and Keeler");
		return;
	}

	if(%topic $= "Commands")
	{
		messageClient(%client, '', "\c6Commands:");
		messageClient(%client, '', "\c61. /nojetsme-turns you into a no-jets player");
		messageClient(%client, '', "\c62. /Trail- Custom trails for your player made by cruxeis");
		messageClient(%client, '', "\c63. /PM Name Message- Sends a Private message to the provided player");
		messageClient(%client, '', "\c64. /help - this is where you are now");
		messageClient(%client, '', "\c65. /spawn - Sends you to the lobby");
		messageClient(%client, '', "\c66. /spec - Spectate whenever you want");
		return;
	}

	if(%topic $= "KnownBugs")
	{
		messageClient(%client, '', "\c61. When ever an administrator does /createland the ground looses collison for half a second");
		messageClient(%client, '', "\c62. No More Known bug.. Please report any you find to an staff member");
	}

        if(%topic $= "admin")
        {
                if(%client.isAdmin == 0)
		{
			messageClient(%client, '', "\c6Admin: ");
			messageClient(%client, '', "\c61. You are not admin, you can't view this"); 
			return;
		}
		if(%client.isAdmin == 1)
		{
			messageClient(%client, '', "\c6 Please select a number \c2/help admin number");
			messageClient(%client, '', "\c61 -->\c0Secret Commands (1)");
			messageClient(%client, '', "\c62 -->\c0Punishment recommendations (2)");
			messageClient(%client, '', "\c63-->\c0Admin punishments (3)");
                }       
		if(%Admin == 1)
		{
			MessageClient(%client, '', "\c6/warn name reason- sends a warning to the specified person. Kicks on third time");
			MessageClient(%client, '', "\c6/Normalme -gives you jets");
			messageClient(%client, '', "\c6/A (Text Goes here)  staff chat");
			messageClient(%client, '', "\c6/kill name - kills a player");
			messageClient(%client, '', "\c6/LlamaMe - turns you into a llama");
			messageClient(%client, '', "\c6/CowMe - Turs you into a cow");
			messageClient(%client, '', "\c6/CloakMe- Turns you invisible");
			messageClient(%client, '', "\c6/Unhidenodeall - Unhides all nodes(very awkward)");
			messageClient(%client, '', "\c6/EnergizeMe - Makes you go fast");
			messageClient(%client, '', "\c6/CreateLand - Creates a new ground 20,000 bricks in the air. **This makes the Regular ground loose collison for a tiny bit!");
			
                }
                if(%admin == 2)
		{
      			messageClient(%client, '', "\c6Spamming(chat)- Warn first, Mute second, kick third");
			messageClient(%client,'', "\c6Asking for Admin persistently- Warn first, kick second");
			messageClient(%client,'', "\c6Being R00DZ- punishment depends on the severity");
			messageClient(%client,'', "\c6Spamming(Other)- clear Their bricks, and warn them. If done again, kick them");
		}
		if(%admin == 3)
		{
			messageClient(%client,'',"\c6Breaking a regular player rule - its breaking a rule, you get the punishment the non-staff player gets");
			messageClient(%client,'',"\c6Changing Enviornment - It breaks the server, and ill get mad");
			messageClient(%client,'',"\c6Abusing powers - De-Admined");
			messageCLient(%client,'',"\c6Playing around with admin ablilites while in minigame - De-Admined");
			messageClient(%client,'',"\c6UN-BANNING - Ill get pissed..just dont do it please");
			messageClient(%client,'',"\c6Trolling or abusing Eval -Depends on situation");
			messageClient(%client,'',"\c6Not Treating others with respect - De-Admined");
		}
			
	}
}
			
		






			