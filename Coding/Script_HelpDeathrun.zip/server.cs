//////////////////
//Help Command Deathrun//////
//////////////////
//Author: Agent Red//
//////////////////

function servercmdHelp(%client,%topic,%Staff)
{
	if(%topic $= "")
	{
		messageClient(%client, '', "\c6Please Choose a Topic. (Ex: /help Rules)");
		messageClient(%client, '', "\c0Rules\c6, \c1 About\c6, \c2 Commands\c6, \c3 KnownBugs\c6, \c4 Staff");
		return;
	}

	if(%topic $= "rules")
	{
		messageClient(%client, '', "\c4Rules:");
                messageClient(%client, '', "\c61.  Do not cause needless arguments");
                messageClient(%client, '', "\c62.  Do not Ask/say you \"Need\" admin- We just wont just give admin, so please stop trying.");
                messageClient(%client, '', "\c63.  Do not spam (chat,musicbricks,emitters,lights, etc)");
                messageClient(%client, '', "\c64.  Play nicely");
		messageClient(%client, '', "\c65.  Do not cheat");
		messageClient(%client, '', "\c66.  Obey what the staff members say");
		messageClient(%client, '', "\c67.  Dont stall the game");
		messageClient(%client, '', "\c2Staff Rules");
		messageClient(%client, '', "\c61.) Do not change the Enviornmental Settings");
		messageClient(%client, '', "\c62.) Do not abuse your powers");
		messageClient(%client, '', "\c63.) Do not Un-Ban Anyone from the ban list");
		messageClient(%client, '', "\c64.) No trolling Around");
		messageClient(%client, '', "\c65.) Treat others/Lower level staff/Normal people equally");
		messageClient(%client, '', "\c66.) All normal server rules- Those still apply to you");
		messageClient(%client, '', "\c67.) No messing around with players while there Inside the game- This also counts as abusing your powers");
		messageClient(%client, '', "\c68.) Help those in need");
		return;
	}
	
	if(%topic $= "About")
	{
		messageClient(%client, '', "\c3About \c6this server:");
		messageClient(%client, '', "\c61. Deathrun is a game�where players, called \c3Runners\c6 try to avoid the traps set�off by a�single�person, Aka \c8Death\c6. It is based off of skill and luck.");
		messageClient(%client, '', "\c6At the end, the Runners�challenge�the Death�to die");
		messageClient(%client, '', "\c62. This server was created by Agent Red, Rocket, K1ng S4vage, Chillah, Cruxeis, DatGuyT_T, Survival and Keeler");
		messageClient(%client, '', "\c63. For more information including an update log, staff applications, and map donations please join our <a:https://discord.gg/dwxqYXX>discord</a> \c6server");
	
		return;
	}

	if(%topic $= "Commands")
	{
		messageClient(%client, '', "\c6Commands:");
		messageClient(%client, '', "\c61. /Nojetsme- Turns you into a no-jets player");
		messageClient(%client, '', "\c62. /Llamame - Turns you into a llama");
		messageClient(%client, '', "\c63. /Trail- Custom trails for your player made by cruxeis");
		messageClient(%client, '', "\c64. /PM Name Message- Sends a Private message to the provided player");
		messageClient(%client, '', "\c65. /Help - this is where you are now");
		messageClient(%client, '', "\c66. /Spawn - Sends you to the lobby");
		messageClient(%client, '', "\c67. /Spec - Spectate whenever you want (you can also press your cancelbrick key to toggle this");
		return;
	}

	if(%topic $= "KnownBugs")
	{
		messageClient(%client, '', "\c61. When ever an administrator does /createland the ground looses collison for 0.1 of a second");
		messageClient(%client, '', "\c62. Sometimes the bricks will overlap (this is an engine issue, its not fixable)");
		messageClient(%client, '', "\c6No More Known bugs.. Please report any you find to an staff member");
	}

        if(%topic $= "Staff")
        {
                if(%client.isAdmin || %client.isGlobalModerator || %client.isModerator == 0)
		{
			messageClient(%client, '', "\c6Staff: ");
			messageClient(%client, '', "\c61. You are not staff, you can't view this"); 
			return;
		}
		if(%client.isAdmin || %client.isGlobalModerator || %client.isModerator == 1)
		{
			messageClient(%client, '', "\c6 Please select a number \c2/help staff #");
			messageClient(%client, '', "\c61 -->\c0Secret Commands (1)");
			messageClient(%client, '', "\c62 -->\c0Punishment recommendations (2)");
			messageClient(%client, '', "\c63-->\c0Staff punishments (3)");
                }       
		if(%Staff == 1)
		{
			MessageClient(%client, '', "\c6/warn name reason- sends a warning to the specified person. Kicks on third time ");
			MessageClient(%client, '', "\c6/Normalme -gives you jets");
			messageClient(%client, '', "\c6/A (Text Goes here)  staff chat");
			messageClient(%client, '', "\c6/kill name - kills a player");
			messageClient(%client, '', "\c6/LlamaMe - turns you into a llama");
			messageClient(%client, '', "\c6/CowMe - Turs you into a cow");
			messageClient(%client, '', "\c6/CloakMe- Turns you invisible");
			messageClient(%client, '', "\c6/Unhidenodeall - Unhides all nodes(very awkward)");
			messageClient(%client, '', "\c6/EnergizeMe - Makes you go fast");
			messageClient(%client, '', "\c6/CreateLand - Creates a new ground 20,000 bricks in the air. **This makes the Regular ground loose collison for a tiny bit!");
			messageClient(%client, '', "\c6/QMT - Teleports you to the Quick Map Teleporter");
			
                }
                if(%Staff == 2)
		{
      			messageClient(%client, '', "\c6Spamming(chat)- Warn first, Mute second, kick third");
			messageClient(%client,'', "\c6Asking for Admin persistently- Warn first, kick second");
			messageClient(%client,'', "\c6Being rude- punishment depends on the severity, do what you want (thats not stupid)");
			messageClient(%client,'', "\c6Spamming(Other)- clear Their bricks, and warn them. If done again, kick them");
			messageClient(%client,'', "\c6Cheating - punishment depends on severity, do what you want (BLHACK = Immediate perma ban)");
			messageClient(%client,'', "\c6Stalling - /kill, or kick them");
		}
		if(%Staff == 3)
		{
			messageClient(%client,'',"\c6Breaking a regular player rule - its breaking a rule, you get the punishment the non-staff player gets");
			messageClient(%client,'',"\c6Changing Enviornment - It breaks the server, Just dont do it, it breaks the server and its annoying as hell");
			messageClient(%client,'',"\c6Abusing powers - De-Admined");
			messageCLient(%client,'',"\c6Playing around with admin ablilites while in minigame(counts as abusing powers) - De-Admined");
			messageClient(%client,'',"\c6UN-BANNING - Ill get pissed..just dont do it please- Warned..");
			messageClient(%client,'',"\c6Trolling or abusing Eval -Warned");
			messageClient(%client,'',"\c6Not Treating others with respect - Warned");
			messageClient(%client,'',"\c3REMINDER\c6: All staff members get a total of two warnings before they get De-Admined..They do NOT reset");
		}
			
	}
}
			
		






			