//Actual forcekill
//Made by Agent Red, BL_ID 40251

function serverCmdKill(%client, %target)
{
	%cName = %client.getPlayerName();
	if(!%client.getadminlevel())
	{
		writeToFile("config/server/AdminLogs/killLog.txt", "" @ %cName SPC "a/>" SPC %target);
		return messageClient(%client, '', "\c3You aren't staff");
	}
	if(!isObject(findClientbyName(%target)))
	{
		writeToFile("config/server/AdminLogs/killLog.txt", "" @ %cName SPC "c/>" SPC %target);
		return messageClient(%client, '', "\c3Invalid client.");
	}
	if(!isObject(%player = findClientbyName(%target).player))
	{
		writeToFile("config/server/AdminLogs/killLog.txt", "" @ %cName SPC "p/>" SPC %target);
		return messageClient(%client, '', "\c3Client does not have player object.");
	}
	else
	{
		%player.kill();
		messageClient(%client, '', "\c4" @ findClientbyName(%target).getPlayerName() SPC "\c3has been killed.");
		writeToFile("config/server/AdminLogs/killLog.txt", "" @ %cName SPC ">" SPC findClientbyName(%target).getPlayerName());
	}
}