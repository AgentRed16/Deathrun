//Server_AdminLevels
//Made by Cruxeis, BL_ID 35041

package adminLevelsPackage {

function GameConnection::autoAdminCheck(%this)
{
	if(%this.getBLID() == getNumKeyID() || %this.isLocal())
		%this.isHost = true;
	if($Pref::Server::CoHost == %this.getBLID())
	{
		%this.isCoHost = true;
		messageAll('', "\c3" @ %this.getPlayerName() SPC "\c2has become \c3Co-Host");
	}
	if($Pref::Server::Developer[%this.getBLID()])
	{
		%this.isDeveloper = true;
		messageAll('', "\c3" @ %this.getPlayerName() SPC "\c2has become \c1Developer");
	}
	if($Pref::Server::GlobalModerator == %this.getBLID())
	{
		%this.isGlobalModerator = true;
		messageAll('', "\c3" @ %this.getPlayerName() SPC "\c2has become Global Moderator");
	}
	if($Pref::Server::Moderator[%this.getBLID()])
	{
		%this.isModerator = true;
		messageAll('', "\c3" @ %this.getPlayerName() SPC "\c2has become \c4Moderator");
	}
	if($Pref::Server::Mute[%this.getBLID()])
	{
		%this.isMuted = true;
		%this.muteLength = $Pref::Server::MuteLengthRemaining[%this.getBLID()];
		%target.unMuteSched = %target.schedule(%target.muteLength, setAttribute, "isMuted", false);
		%target.unMutePrintSched = %target.schedule(%target.muteLength, chatMessage, "\c3You can talk now.");
		%target.unMuteVarSched = schedule(%target.muteLength, 0, eval, "$Pref::Server::Mute[" @ %this.getBLID() @ "]=false;");
		%this.chatMessage("\c3You still have \c0" @ getTimeRemaining(%this.unMuteSched) / 1000 / 60 SPC "minutes \c3left on your mute.");
	}
	return Parent::autoAdminCheck(%this);
}

function serverCmdMessageSent(%client, %message)
{
	if(%client.isMuted)
		return %client.chatMessage("\c3You are still muted with \c0" @ (getTimeRemaining(%client.unMuteSched) / 1000 / 60) SPC "minutes \c3remaining.");
	else
		return Parent::serverCmdMessageSent(%client, %message);
}

function GameConnection::onClientLeaveGame(%this, %a, %b, %c)
{
	if(%this.isMuted)
	{
		$Pref::Server::Mute[%this.getBLID()] = true;
		$Pref::Server::MuteLengthRemaining[%this.getBLID()] = getTimeRemaining(%this.unMuteSched);
	}
	Parent::onClientLeaveGame(%this, %a, %b, %c);
}

};

activatePackage(adminLevelsPackage);

function serverCmdSpy(%client, %victim)
{
	if(!%client.getAdminLevel())
		return;
	if(isObject(%victimPlayer = findClientByName(%victim).player))
	{
		%client.camera.setMode("Corpse", %victimPlayer);
		%client.setControlObject(%client.camera);
		%client.isSpying = true;
	}
	else
		return %client.chatMessage("Player not found");
}

function serverCmdKick(%client, %victim, %reason)
{
	if(!%client.getAdminLevel())
		return;
	if(isObject(%target = findClientByName(%victim)))
	{
		if(%client.getAdminLevel() < %target.getAdminLevel())
			return %client.chatMessage("\c3You can't kick someone higher than you");
		%target.delete();
		messageAll('', "\c3" @ %client.getPlayerName() SPC "\c2kicked \c3" @ %target.getPlayerName() SPC "\c2(ID:" SPC %target.getBLID() @ ")");
	}
}

function serverCmdFind(%client, %victim)
{
	if(!%client.getAdminLevel())
		return;
	if(isObject(%target = findClientByName(%victim).player))
	{
		%client.player.setTransform(%target.getTransform());
		%client.player.teleportEffect();
	}
}

function serverCmdFetch(%client, %victim)
{
	if(%client.getAdminLevel() < 2)
		return;
	if(isObject(%target = findClientByName(%victim).player))
	{
		%target.setTransform(%client.player.getTransform());
		%client.player.teleportEffect();
	}
}

function serverCmdWarp(%client)
{
	if(%client.getAdminLevel() < 2)
		return;
	%start = %client.player.getEyePoint();
	%end = VectorAdd(%start, VectorScale(%client.player.getEyeVector(), 512));
	%raycast = ContainerRayCast(%start, %end, -1, %client.player);
	if(isObject(%raycast))
		%final = posFromRayCast(%raycast);
	%client.player.setTransform(%final);
	%client.player.teleportEffect();
}

function serverCmdMute(%client, %victim, %time)
{
	if(!%client.getAdminLevel())
		return;
	if(%time > 16)
	{
		%client.chatMessage("\c3You can't mute someone for more than \c016 minutes.");
		serverCmdMute(%client, %victim, 16);
		return;
	}
	if(isObject(%target = findClientByName(%victim)))
	{
		if(!%target.isMuted)
		{
			%target.isMuted = true;
			%target.muteLength = %time * 1000 * 60;
			%target.chatMessage("\c3You have been muted for \c0" @ %time SPC "minutes.");
			%target.unMuteSched = %target.schedule(%target.muteLength, setAttribute, "isMuted", false);
			%target.unMutePrintSched = %target.schedule(%target.muteLength, chatMessage, "\c3You can talk now.");
			%client.chatMessage("\c3You have muted \c2" @ %target.getPlayerName() SPC "\c3for \c0" @ %time SPC "minutes.");
		}
		else
		{
			%client.chatMessage("\c3That person has already been muted for \c0" @ (%target.muteLength / 1000 / 60) SPC "minutes.");
			%client.chatMessage("\c3They have \c0" @ (getTimeRemaining(%target.unMuteSched) / 1000 / 60) SPC "minutes \c3remaining.");
		}
	}
	else
		return %client.chatMessage("\c3Mute error - invalid victim!");
}

function serverCmdUnMute(%client, %victim)
{
	if(!%client.getAdminLevel())
		return;
	if(isObject(%target = findClientByName(%victim)))
	{
		if(%target.isMuted)
		{
			cancel(%target.unMuteSched);
			cancel(%target.unMutePrintSched);
			if(isEventPending(%target.unMuteVarSched))
			{
				cancel(%target.unMuteVarSched);
				$Pref::Server::Mute[%target.getBLID()] = false;
				$Pref::Server::MuteLengthRemaining[%target.getBLID()] = 0;
			}
			%target.isMuted = false;
			%target.chatMessage("\c3You have been unmuted.");
		}
		else
			return %client.chatMessage("\c3That person is not muted!");
	}
	else
		return %client.chatMessage("\c3Unmute error - invalid victim!");
}

function serverCmdWarn(%client, %victim, %reason0, %reason1, %reason2, %reason3, %reason4, %reason5, %reason6, %reason7, %reason8, %reason9, %reason10, %reason11, %reason12, %reason13, %reason14, %reason15, %reason16, %reason17)
{
	if(!%client.getAdminLevel())
		return;
	for(%i = 0; %i < 18; %i++)
		%reason = %reason SPC %reason[%i];
	if(isObject(%target = findClientByName(%victim)))
	{
		if(%target.getAdminLevel() > 1)
			return %client.chatMessage("\c3Warn error - this person can't be warned.");
		writeToFile("config/warnings.txt", getDateTime() TAB %target.totalWarnings TAB %client.getPlayerName() SPC %client.getBLID() TAB %target.getPlayerName() SPC %target.getBLID() TAB %reason);
		if(%target.totalWarnings == 2)
		{
			messageAll('', "\c3" @ %client.getPlayerName() SPC "\c2kicked" SPC "\c3" @ %target.getPlayerName() SPC "\c2(ID:" SPC %target.getBLID() @ ")");
			%target.delete();
		}
		else
		{
			%target.totalWarnings++;
			%client.chatMessage("\c3You have \c0warned \c3" @ %target.getPlayerName() SPC "\c3for \c0" @ %reason); 
			%target.chatMessage("\c3You have been \c0warned: \c6" @ %reason);
			%target.chatMessage("\c3This is warning \c0" @ %target.totalWarnings @ ". \c3You will be kicked on warning 3.");
		}
	}
	else
		return %client.chatMessage("\c3Warn error - That person does not exist.");
}

function serverCmdGiveMod(%client, %victim)
{
	if(%client.getAdminLevel() < 6)
		return;
	if(isObject(%target = findClientByName(%victim)))
	{
		if(!%target.isModerator)
		{
			messageAll('MsgAdminForce', "\c3" @ %target.getPlayerName() SPC "\c2has become \c4Moderator");
			%target.isModerator = true;
			$Pref::Server::Moderator[%target.getBLID()] = true;
		}
		else
			return %client.chatMessage("\c3GiveMod error - that person is already a moderator.");
	}
	else
		return %client.chatMessage("\c3GiveMod error - that person does not exist.");
}

function serverCmdTakeMod(%client, %victim)
{
	if(!(%client.isGlobalModerator || %client.isCoHost || %client.isHost))
		return;
	if(isObject(%target = findClientByName(%victim)))
	{
		if(%target.isModerator)
		{
			messageAll('MsgError', "\c3" @ %target.getPlayerName() SPC "\c2is no longer \c4Moderator");
			%target.isModerator = false;
			$Pref::Server::Moderator[%target.getBLID()] = false;
		}
		else
			return %client.chatMessage("\c3TakeMod error - that person is not a moderator.");
	}
	else
		return %client.chatMessage("\c3TakeMod error - that person does not exist.");
}

function serverCmdGiveDev(%client, %victim)
{
	if(%client.getAdminLevel() < 6)
		return;
	if(isObject(%target = findClientByName(%victim)))
	{
		if(!%target.isDeveloper)
		{
			messageAll('MsgAdminForce', "\c3" @ %target.getPlayerName() SPC "\c2has become \c1Developer");
			%target.isDeveloper = true;
			$Pref::Server::Developer[%target.getBLID()] = true;
		}
		else
			return %client.chatMessage("\c3GiveDev error - that person is already a developer.");
	}
	else
		return %client.chatMessage("\c3GiveDev error - that person does not exist.");
}

function serverCmdTakeDev(%client, %victim)
{
	if(%client.getAdminLevel() < 6)
		return;
	if(isObject(%target = findClientByName(%victim)))
	{
		if(%target.isDeveloper)
		{
			messageAll('MsgAdminForce', "\c3" @ %target.getPlayerName() SPC "\c2is no longer \c1Developer");
			%target.isDeveloper = false;
			$Pref::Server::Developer[%target.getBLID()] = false;
		}
		else
			return %client.chatMessage("\c3TakeDev error - that person is not a developer.");
	}
}

function serverCmdStaffShutdown(%client)
{
	if(%client.getAdminLevel() < 6)
		return;
	else
	{
		messageAll('MsgClearBricks', "\c3Server is being shut down for maintenance...");
		messageAll('', "\c23");
		schedule(1000, 0, messageAll, '', "\c32");
		schedule(2000, 0, messageAll, '', "\c01");
		schedule(3000, 0, staffShutdown);
	}
}

function serverCmdLaunch(%client, %victim) //Needs Script_CruxEval to work!
{
	if(%client.getAdminLevel() < 5)
		return;
	if(isObject(%target = findClientByName(%victim)))
		if(isObject(%player = %target.player))
			%player.lf();
	else
		return %client.chatMessage("\c3Launch error - player not found");
}

function serverCmdPM(%client, %victim, %word0, %word1, %word2, %word3, %word4, %word5, %word6, %word7, %word8, %word9, %word10, %word11, %word12, %word13, %word14, %word15, %word16, %word17)
{
	for(%i = 0; %i < 18; %i++)
		%message = trim(%message SPC %word[%i]);
	if(isObject(%target = findClientByName(%victim)))
	{
		%client.chatMessage("\c2You \c6> \c1" @ %target.getPlayerName() @ "\c3:" SPC %message);
		%target.chatMessage("\c1" @ %client.getPlayerName() SPC "\c6> \c2You\c3:" SPC %message);
		echo(getDateTime() SPC %client.getPlayerName() SPC ">" SPC %target.getPlayerName() SPC %message);
		writeToFile("config/PMLog.txt", getDateTime() TAB %client.getPlayerName() TAB %target.getPlayerName() TAB %message);
	}
	else
		%client.chatMessage("\c3PM Error - person does not exist");
}

function serverCmdNormalMe(%client)
{
	if(%client.getAdminLevel() < 3 || isObject(%client.miniGame))
		return;
	if(isObject(%player = %client.player))
	{
		%player.unHideNode("headSkin");
		%player.changeDatablock("PlayerStandardArmor");
	}
}

function serverCmdNoJetsMe(%client)
{
	if(isObject(%player = %client.player))
		%player.changeDatablock("PlayerNoJet");
}

function GameConnection::getAdminLevel(%this)
{
	if(%this.isHost) return 7;
	if(%this.isCoHost) return 6;
	if(%this.isDeveloper) return 5;
	if(%this.isSuperAdmin) return 4;
	if(%this.isAdmin) return 3;
	if(%this.isGlobalModerator) return 2;
	if(%this.isModerator) return 1;
	else return 0;
}

function writeToFile(%path, %line)
{
	%file = new fileObject();
	%file.openForAppend(%path);
	%file.writeLine(%line);
	%file.close();
	%file.delete();
}

function staffShutdown()
{
	%count = clientGroup.getCount();
	for(%i = %count; %i > 0; %i--)
		if((%client = clientGroup.getObject(%i)).getAdminLevel() < 1)
			%client.delete();
}
			
			

