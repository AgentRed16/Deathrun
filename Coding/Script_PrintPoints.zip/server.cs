//Script_PrintPoints
//Made by Cruxeis, BL_ID 35041

package printPointsPackage {

function Slayer_MinigameSO::addMember(%mini)
{
	Parent::addMember(%mini);
	cancel($printPointsSched);
	printPointsLoop();
}

function Slayer_MinigameSO::onReset(%mini)
{
	Parent::onReset(%mini);
	cancel($printPointsSched);
	printPointsLoop();
}

};

activatePackage(printPointsPackage);

function printPointsLoop()
{
	if(getMinigameByTitle("Deathrun").numMembers == 0)
	{
		bottomPrintAll("");
		cancel($printPointsSched);
		return;
	}
	%count = clientGroup.getCount();
	%runners = getMinigameByTitle("Deathrun").getTeam("Runners").getNumLiving();
	if(isObject(%death = getMinigameByTitle("Deathrun").getTeam("Death").member[0]))
		%deathName = getMinigameByTitle("Deathrun").getTeam("Death").member[0].getPlayerName();
	for(%i = 0; %i < %count; %i++)
	{
		%score[%i] = clientGroup.getObject(%i).score; 
		if(!getMinigameByTitle("Deathrun").isResetting)
			bottomPrint(clientGroup.getObject(%i), "\c3Runners Alive\c6:" SPC %runners @ "<just:right>\c4Score\c6:" SPC %score[%i] @ "<br><just:left>\c7Death\c6:" SPC %deathName);
	}
	$printPointsSched = schedule(500, 0, printPointsLoop);
}

function Slayer_TeamSO::getNumLiving(%team)
{
	if(%team.numMembers == 0)
		return 0;
	%count = %team.numMembers;
	for(%i = 0; %i < %count; %i++)
	{
		if(isObject(%team.member[%i].player))
			%num++;
	}
	if(%num == 0 || %num $= "")
		return "0";
	else return %num;
}	

function Slayer_MinigameSO::getTeam(%mini, %team)
{
	%count = %mini.teams.getCount();
	for(%i = 0; %i < %count; %i++)
	{
		if(%mini.teams.getObject(%i).name $= %team)
			return %mini.teams.getObject(%i);
	}
}
			
function getDefaultMinigame()
{
	%count = Slayer_MinigameHandlerSG.getCount();
	for(%i = 0; %i < %count; %i++)
	{
		%obj = Slayer_MinigameHandlerSG.getObject(%i);
		if(%obj.isDefaultMinigame)
			return %obj;
	}
}			