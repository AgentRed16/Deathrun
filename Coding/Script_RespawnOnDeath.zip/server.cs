//Script_RespawnOnDeath
//Made by Cruxeis, BL_ID 35041

package respawnOnDeathPackage {
	
function GameConnection::onDeath(%this, %killerPlayer, %killer, %damageType, %damageLoc)
{
	Parent::onDeath(%this, %killerPlayer, %killer, %damageType, %damageLoc);
	%this.spawnPlayer();
}

};

activatePackage(respawnOnDeathPackage);