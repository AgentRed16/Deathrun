//Team teleport for Slayer
//Made by Cruxeis, BL_ID 35041

function GameConnection::teleportSlayerTeam(%this, %team, %transform)
{
	%teamcount = %this.minigame.teams.getCount();
	for(%i = 0; %i < %teamcount; %i++)
	{
		if(%this.minigame.teams.getObject(%i).name !$= %team)
			continue;
		else
		{
			%playercount = %this.minigame.teams.getObject(%i).numMembers;
			for(%j = 0; %j < %playercount; %j++)
			{
				if(isObject(%individual = %this.minigame.teams.getObject(%i).member[%j].player))
					%individual.setTransform(VectorAdd(%transform, getRandom(0, 5) SPC getRandom(0, 5) SPC "0"));
			}
		}
	}
}

registerOutputEvent("GameConnection", "teleportSlayerTeam", "string 175 175	string 175 175", true);