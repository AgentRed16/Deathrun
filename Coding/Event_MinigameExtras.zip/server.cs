//Event_MinigameExtras
//Made by Cruxeis, BL_ID 35041

function Slayer_MinigameSO::chooseRandPlayer(%this, %transform)
{
	%count = %this.numMembers;
	%rand = getRandom(0, (%count - 1));
	%client = %this.member[%rand];
	%client.spawnPlayer();
	%client.player.setTransform(%transform);
}

function Slayer_MinigameSO::allJoinTeam(%this, %team)
{
	%count = %this.numMembers;
	for(%i = 0; %i < %count; %i++)
		%this.member[%i].joinTeam(%team);
}

registerOutputEvent("Minigame", "chooseRandPlayer", "string 150 150", true);
registerOutputEvent("Minigame", "allJoinTeam", "string 150 150", true);