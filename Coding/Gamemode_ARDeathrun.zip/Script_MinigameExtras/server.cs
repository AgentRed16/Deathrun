package arPackage {

function Slayer_MinigameSO::removeMember(%this, %member)
{
    Parent::removeMember(%this, %member);
    if(%this.title $= "Lobby")
        getMinigameByTitle("Deathrun").addMember(%member);
    else if(%this.title $= "Deathrun")
	getMinigameByTitle("Lobby").addMember(%member);
}

};

activatePackage(arPackage);