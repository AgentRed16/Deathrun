//Expansion pack for all of the things on the list
//Made by Cruxeis, BL_ID 35041

package buildPaintOverride {
	
function serverCmdPlantBrick(%client)
{
	if(%client.buildingRestricted)
		return %client.centerPrint("Building is restricted!", 2);
	parent::serverCmdPlantBrick(%client);
}

function serverCmdBSD(%client)
{
	if(%client.buildingRestricted)
		return %client.centerPrint("Building is restricted!", 2);
	parent::serverCmdBSD(%client);
}

function serverCmdUseInventory(%client, %num)
{
	if(%client.buildingRestricted)
		return %client.centerPrint("Building is restricted!", 2);
	parent::serverCmdUseInventory(%client, %num);
}

function serverCmdUseSprayCan(%client, %num)
{
	if(%client.paintingRestricted)
		return %client.centerPrint("Painting is restricted!", 2);
	parent::serverCmdUseSprayCan(%client, %num);
}

function serverCmdUseFXCan(%client, %num)
{
	if(%client.paintingRestricted)
		return %client.centerPrint("Painting is restricted!", 2);
	parent::serverCmdUseFXCan(%client, %num);
}

function GameConnection::setBuildingRestricted(%this, %bool)
{
	%this.buildingRestricted = %bool;
}

function GameConnection::setPaintingRestricted(%this, %bool)
{
	%this.paintingRestricted = %bool;
}

};

activatePackage(buildPaintOverride);

function serverCmdClearCreative(%client)
{
	%mainCount = mainBrickGroup.getCount();
	for(%i = 0; %i < %mainCount; %i++)
	{
		%group = mainBrickGroup.getObject(%i);
		%name = mainBrickGroup.getObject(%i).getName();
		if(%name $= "brickGroup_" @ getNumKeyID() || strStr($Pref::Server::AutoSuperAdminList, getSubStr(%name, 11, strlen(%name))) != -1 || %name $= "brickGroup_888888" || %name $= "brickGroup_999999")
			continue;
		%groupCount = %group.getCount();
		for(%j = %groupCount; %j > -1; %j--)
		{
			%obj = %group.getObject(%j);
			%obj.schedule(%i*100, delete);
		}
	}
}

function GameConnection::removeFromMini(%this)
{
	if(isObject(%mini = %this.minigame))
		%mini.removeMember(%this);
}

function GameConnection::addToMini(%this, %title)
{
	if(isObject(%mini = getMinigameByTitle(%title)))
		%mini.addMember(%this);
}
	
function getMinigameByTitle(%title)
{
	if(%title $= "" || %title $= " ")
		return false;
	if(isObject(Slayer_MinigameHandlerSG))
	{
		for(%i = 0; %i < Slayer_MinigameHandlerSG.getCount(); %i++)
		{
			%mini = Slayer_MinigameHandlerSG.getObject(%i);
			if(%mini.title $= %title)
				return %mini;
		}
	}
	if(isObject(MiniGameGroup))
	{
		for(%i = 0; %i < MiniGameGroup.getCount(); %i++)
		{
			%mini = MiniGameGroup.getObject(%i);
			if(%mini.title $= %title)
				return %mini;
		}
	}
	else
		return false;
}
			
function serverCmdRTD(%client)
{
	if(isObject(%mini = %client.minigame))
		%mini.ADDMember(%client);
}











			
registerOutputEvent("GameConnection", "removeFromMini", "", 1);
registerOutputEvent("GameConnection", "addToMini", "string 25 25", 1);
registerOutputEvent("GameConnection", "setBuildingRestricted", "bool", 1);
registerOutputEvent("GameConnection", "setPaintingRestricted", "bool", 1);