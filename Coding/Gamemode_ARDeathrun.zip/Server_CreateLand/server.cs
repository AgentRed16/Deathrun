//Create an extra fxPlane 10,000 bricks up!
//Made by Cruxeis, BL_ID 35041

function serverCmdCreateLand(%client)
{
	if(%client.isAdmin == 1)
	{
		groundPlane.save("config/groundPlane.cs");
		groundPlane.setName("highGround");
		highGround.setTransform("0 0 4999.5");
		highGround.sendUpdate();
		exec("config/groundPlane.cs");
	}
}
		