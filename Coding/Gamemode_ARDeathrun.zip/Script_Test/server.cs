function GameConnection::SaveScore(%client)
	{
		%score = %client.score;
		%file = new FileObject();
		%file.openforwrite("Config/Server/SavedScores/"@%client.bl_id@".txt");
		%file.writeline(%score);
		%file.close();
		%file.delete();
	}

function GameConnection::LoadScore(%client)
	{
		%file = new FileObject();
		%file.openforread("Config/Server/SavedScores/"@%client.bl_id@".txt");
		%score = %file.readline();
		%client.setscore(%score);
		%file.close();
		%file.delete();
	}
registerOutputEvent("GameConnection", "saveScore", "", 0);
registerOutputEvent("GameConnection", "loadscore", "", 0);

