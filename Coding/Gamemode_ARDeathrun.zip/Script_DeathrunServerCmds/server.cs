
function serverCmdLlamaMe(%client)
{
	if(isObject(%player = %client.player))
		%player.changedatablock("LlamaArmor");
}
function serverCmdCloakMe(%client)
{
	if(isObject(%player = %client.player) && %client.isAdmin || %client.isGlobalModerator)
		%player.changedatablock("PlayerHiddenArmor");
		%player.setShapeNameDistance(0);
}
function serverCmdCowMe(%client)
{	
	if(isObject(%player = %client.player) && %client.isAdmin || %client.isGlobalModerator)
		%player.changedatablock("CowArmor");
}
function serverCmdUnhideNodeAll(%client)
{
	if(isObject(%player = %client.player) && %client.isAdmin || %client.isGlobalModerator)
	{
		%player.changedatablock("PlayerStandardArmor");
		%client.player.Unhidenode("ALL");
	}
}
function serverCmdEnergizeMe(%client)
{
	if(isObject(%player = %client.player) && %client.isAdmin || %client.isGlobalModerator)
		%player.changedatablock("PlayerQuakeArmor");
}
function serverCmdListMaps(%client)
{
	messageClient(%client, '', "\c2Map List");
	messageClient(%client, '', "\c3 1) \c6 MAP 1: Creative");
	messageClient(%client, '', "\c3 2) \c6 MAP 2: City");
	messageClient(%client, '', "\c3 3) \c6 MAP 3: Biomes");
	messageClient(%client, '', "\c3 4) \c6 MAP 4: Skylands");
}	
function serverCmdQMT(%client)
{
	if(%client.isAdmin || %client.isGlobalModerator || %client.isModerator)
	{
		%client.player.setTransform("173 58.5 1.1");
		%client.player.setScale("1 1 1");
	}
}